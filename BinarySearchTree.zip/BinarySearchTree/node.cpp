#include "node.h"

Node::Node(int value) {
	this->value = value; 
	this->parent = NULL;
	this->leftChild = NULL;
	this->rightChild = NULL;

}
Node::Node(int value, Node *parent, Node *leftChild, Node *rightChild) {
	this->value = value;
	this->parent = parent;
	this->leftChild = leftChild;
	this->rightChild = rightChild;
}

Node::~Node() {
	this->parent = NULL;
	this->leftChild = NULL; 
	this->rightChild = NULL; 
}

int Node::GetValue() {
	return value;
}

Node* Node::GetParent() {
	return parent;
}

Node* Node::GetLeft() {
	return leftChild;
}

Node* Node::GetRight() {
	return rightChild;
}

void Node::SetParent(Node *temp) {
	this->parent = temp;
}

void Node::SetLeft(Node *temp) {
	this->leftChild = temp;
}

void Node::SetRight(Node *temp) {
	this->rightChild = temp;
}
