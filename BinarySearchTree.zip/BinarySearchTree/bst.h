#ifndef __BST_H__
#define __BST_H__

#include "node.h"

// Defines a binary tree.
class BST {
private:
	Node *root;
public:
	// Constructor for BST 
	BST();

	// Destructor for BST
	~BST();
	
	// Inorder traversal for 
	void inorderTreeWalk(Node *currentNode);
	
	// Preorder traversal for BST
	void preorderTreeWalk(Node *currentNode);
	
	// Postorder traversal for BST
	void postorderTreeWalk(Node *currentNode);

	//GetNodeRecursive return checks for value in tree in recursion
	Node* GetNodeRecursive(Node *currentNode, int value);

	// Returns the node with the specified value.
	Node* GetMaxNode(); 
	
	// Returns the root of the tree.
	Node* GetRoot();

	// Adds the value to the tree.
	void AddValue(int value);

	// Remove the value from the tree
	void RemoveNode(int value);
	
	// Returns the node with the specified value.
	Node* GetNode(int value);

	// Prints the list of values from the tree, using the specified order.
	void PrintTreeWalk(int orderNumber);
};

#endif
