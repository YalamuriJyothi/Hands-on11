#include "bst.h"
#include <iostream>
#include <queue>

using namespace std;

BST::BST() {
	root = NULL;
}

BST::~BST() {
	
}

Node* BST::GetRoot( ) {
	return root;
}

void BST::AddValue(int value) {
	
	// Creating a new node (Empty Node)
	Node  *newNode = new Node(value);

	// Set which side of the Parent newNode is added
	bool newNodeleftChild = false;
	
	// Set which side of the Parent newNode is added
	bool parentleftChild = false;
	
	// Checking Red Black Tree tree condition for 4 => a, b Cases
	bool checkRedBlackTree = true;
	

	// Step 1 : if root node is null, add node as root
	if ( root == NULL) {
		root = newNode;
		return;
	}
	// Step 2: Add node to  BST 
	else {
	
		queue<Node*> myQueue;
		myQueue.push(root);
		
		while (!myQueue.empty()) {
			Node* currentNode = myQueue.front();
			myQueue.pop();
		
			if (currentNode->GetValue() > value ) {
				if (currentNode->GetLeft() == NULL) {
					
					//set the parent of new node as currentNode 
					newNode->SetParent(currentNode);
					
					// add new node as currentNode's left child
					currentNode->SetLeft(newNode);

					newNodeleftChild = true;
					break;
				}
				else {
					myQueue.push(currentNode->GetLeft());
				}
			}
			else {
				if (currentNode->GetRight() == NULL) {

					//set the parent of new node as currentNode 
					newNode->SetParent(currentNode);
					
					// add new node as currentNode's right child
					currentNode->SetRight(newNode);
					
					// set the child is the right child
					newNodeleftChild = false;
					break;
				}
				else {
					myQueue.push(currentNode->GetRight());
				}
			}
		}
	}

}

Node* BST::GetNodeRecursive(Node *currentNode, int value ) {
	if (currentNode == NULL) {
		return NULL;
	}
	else if (currentNode->GetValue() == value ) {
		return currentNode;
	}
	else if (currentNode->GetValue() < value ) {
		return GetNodeRecursive(currentNode->GetRight(), value);
	}
	else {
		return GetNodeRecursive(currentNode->GetLeft(), value);
	}
}

Node* BST::GetNode(int value) {
	Node *currentNode = root;
	return GetNodeRecursive(currentNode,value);
}

void BST::RemoveNode(int value) {

	// Get the node associated with value node
	Node *currentNode = GetNode(value);

	if (currentNode == NULL ) 
		return ;
	
	// Step 1 : Performing the BST Deletion here
	
	// Case 1 : If node is leaf node then Delete it
	if (currentNode->GetLeft() == NULL && currentNode->GetRight() == NULL) {
		Node *parent = currentNode->GetParent();
		if (parent->GetLeft() ==  currentNode ) {
			parent->SetLeft(NULL);
		}
		else {
			parent->SetRight(NULL);
		}
		// Red Black Tree

	}
	// Case 2 : If node is has one child only 
	if ((currentNode->GetLeft() == NULL && currentNode->GetRight() != NULL ) || (currentNode->GetLeft() != NULL && currentNode->GetRight() == NULL )) {
		
	}
	else {
		return;
	}

}	

Node * BST::GetMaxNode() {
	queue<Node*> myQueue;
	myQueue.push(root);
	Node *temp = NULL;	
	while (!myQueue.empty()) {
		Node* currentNode = myQueue.front();
		myQueue.pop();
		if (currentNode->GetRight() == NULL) {
			temp = currentNode;
			break;
		}
		else {
			myQueue.push(currentNode->GetRight());
		}
	}
	return temp;
}

void BST::PrintTreeWalk(int orderNumber) {
	if (orderNumber == 1 ) {
		inorderTreeWalk(root);
	}
	else if (orderNumber == 2 ) {
		preorderTreeWalk(root);
	}
	else if (orderNumber == 3 ){
		postorderTreeWalk(root);
	}
}


void BST::inorderTreeWalk(Node *currentNode){
	if (currentNode == NULL) {
		return;
	}
	inorderTreeWalk(currentNode->GetLeft());
	if (currentNode == GetMaxNode()) 
		cout << currentNode->GetValue(); 
		//cout << currentNode->GetValue() << "[" << currentNode->GetColor() << "] " << currentNode->GetParent() <<  " " << currentNode->GetLeft() << " " << currentNode->GetRight() << endl; 
	else
		cout << currentNode->GetValue() << " "; 
		//cout << currentNode->GetValue() << "[" << currentNode->GetColor() << "] " << currentNode->GetParent() <<  " " << currentNode->GetLeft() << " " << currentNode->GetRight() << endl; 
	inorderTreeWalk(currentNode->GetRight());
}

void BST::preorderTreeWalk(Node *currentNode){
	if (currentNode == NULL) {
		return;
	}
	if (currentNode == GetMaxNode()) 
		cout << currentNode->GetValue(); 
	else
		cout << currentNode->GetValue() << " ";
	preorderTreeWalk(currentNode->GetLeft());
	preorderTreeWalk(currentNode->GetRight());
}

void BST::postorderTreeWalk(Node *currentNode){
	if (currentNode == NULL) {
		return;
	}
	postorderTreeWalk(currentNode->GetLeft());
	postorderTreeWalk(currentNode->GetRight());
	if (currentNode == root) 
		cout << currentNode->GetValue(); 
	else
		cout << currentNode->GetValue() << " ";
}
