#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include "rbt.h"
#include "node.h"

using namespace std;

/* You may use this file to test your program.
   This file will not be submitted, as a different test4.cpp will be used.
   Every required method is included here so that you can verify that
   you have included everything the test engine will call. */
int main(int argv, char **argc) {
	RBT mainTree;	// RBT to use for testing
	Node *curNode;	// Current node
	
	cout << "Welcome to the Red Black Tree Implementation Demo" << endl;
	int choice;
	int value;
	bool run = true;
	while(run) {
		cout << "1. Add Value " << endl;
		cout << "2. Search Node of Value: " << endl;
		cout << "3. GetParent of Node Value: " << endl;
		cout << "4. GetLeft of Node Value: " << endl;
		cout << "5. GetRight of Node Value: " << endl;
		cout << "6. Print Tree" << endl;
		cout << "7. Exit from code " << endl;
		cout << "Enter your choice: ";
		cin >> choice;
		cout << endl;
		switch(choice) {
			case 1 : 
				cout << "Enter an integer : " ;
				cin >> value;
				mainTree.AddValue(value);
				break;
			case 2 : 
				cout << "Enter an integer : " ;
				cin >> value;
				curNode = mainTree.GetNode(value);
				cout << "Current Node : Value " << curNode->GetValue() <<  " Color " << curNode->GetColor() << endl;
				break;
			case 3:
				cout << "Enter an integer : " ;
				cin >> value;
				curNode = mainTree.GetNode(value);
				cout << "Parent Node : Value " << curNode->GetParent()->GetValue() <<  " Color " << curNode->GetParent()->GetColor() << endl;
				break;

			case 4:
				cout << "Enter an integer : " ;
				cin >> value;
				curNode = mainTree.GetNode(value);
				if (curNode != NULL)
					cout << "Left Node : Value " << curNode->GetLeft()->GetValue() <<  " Color " << curNode->GetLeft()->GetColor() << endl;
				else
					cout << "Null Node" << endl;

				break;
			case 5:
				cout << "Enter an integer : " ;
				cin >> value;
				curNode = mainTree.GetNode(value);
				if (curNode != NULL) 
					cout << "Right Node : Value " << curNode->GetRight()->GetValue() <<  " Color " << curNode->GetRight()->GetColor() << endl;
				else
					cout << "Null Node" << endl;
				break;

			case 6 :
				cout << "Inorder: " ;
				mainTree.PrintTreeWalk(1);
				cout << endl;
				cout << "Preorder: " ;
				mainTree.PrintTreeWalk(2);
				cout << endl;
				cout << "Postorder: " ;
				mainTree.PrintTreeWalk(3);
				cout << endl;
				
				break;
			case 7 : run = false;
		}
	}
	return 0;
}
