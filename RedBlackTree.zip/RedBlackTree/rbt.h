#ifndef __RBT_H__
#define __RBT_H__

#include "node.h"

// Defines a binary tree.
class RBT {
private:
	Node *root;
public:
	// Constructor for RBT 
	RBT();

	// Destructor for RBT
	~RBT();
	
	// Inorder traversal for 
	void inorderTreeWalk(Node *currentNode);
	
	// Preorder traversal for RBT
	void preorderTreeWalk(Node *currentNode);
	
	// Postorder traversal for RBT
	void postorderTreeWalk(Node *currentNode);

	//GetNodeRecursive return checks for value in tree in recursion
	Node* GetNodeRecursive(Node *currentNode, int value);

	// Returns the node with the specified value.
	Node* GetMaxNode(); 
	
	// Returns the root of the tree.
	Node* GetRoot();

	// Adds the value to the tree.
	void AddValue(int value);

	// Returns the node with the specified value.
	Node* GetNode(int value);

	// Prints the list of values from the tree, using the specified order.
	void PrintTreeWalk(int orderNumber);
};

#endif
