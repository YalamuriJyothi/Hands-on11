#include "node.h"

Node::Node(int value) {
	this->value = value; 
	this->color = 1; // Default Red 
	this->parent = NULL;
	this->leftChild = NULL;
	this->rightChild = NULL;

}
Node::Node(int value, bool color, Node *parent, Node *leftChild, Node *rightChild) {
	this->value = value;
	this->color = color;
	this->parent = parent;
	this->leftChild = leftChild;
	this->rightChild = rightChild;
}

Node::~Node() {
	this->parent = NULL;
	this->leftChild = NULL; 
	this->rightChild = NULL; 
}

void Node::SetValue(int newValue) {
	value = newValue;
}

int Node::GetColor(){
	return color;
}

int Node::GetValue() {
	return value;
}

void Node::SetColor(bool isBlack) {
	if (isBlack == true )
		color = 2;
	else
		color = 1; 
}

Node* Node::GetParent() {
	return parent;
}

Node* Node::GetLeft() {
	return leftChild;
}

Node* Node::GetRight() {
	return rightChild;
}

void Node::SetParent(Node *temp) {
	this->parent = temp;
}

void Node::SetLeft(Node *temp) {
	this->leftChild = temp;
}

void Node::SetRight(Node *temp) {
	this->rightChild = temp;
}
