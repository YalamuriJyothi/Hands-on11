#include "rbt.h"
#include <iostream>
#include <queue>

using namespace std;

RBT::RBT() {
	root = NULL;
}

RBT::~RBT() {
	
}

Node* RBT::GetRoot( ) {
	return root;
}

void RBT::AddValue(int value) {
	
	// Creating a new node (Empty Node)
	Node  *newNode = new Node(value);

	// Set which side of the Parent newNode is added
	bool newNodeleftChild = false;
	
	// Set which side of the Parent newNode is added
	bool parentleftChild = false;
	
	// Checking Red Black Tree tree condition for 4 => a, b Cases
	bool checkRedBlackTree = true;
	

	// Step 1 : if root node is null, add node as root and change color of node to black
	if ( root == NULL) {
		root = newNode;
		root->SetColor(true);
		return;
	}
	// Step 2: Add node to  BST and set color to Red
	else {
	
		queue<Node*> myQueue;
		myQueue.push(root);
		
		while (!myQueue.empty()) {
			Node* currentNode = myQueue.front();
			myQueue.pop();
		
			if (currentNode->GetValue() > value ) {
				if (currentNode->GetLeft() == NULL) {
					//setting new node as Red Color
					newNode->SetColor(false);
					
					//set the parent of new node as currentNode 
					newNode->SetParent(currentNode);
					
					// add new node as currentNode's left child
					currentNode->SetLeft(newNode);

					newNodeleftChild = true;
					break;
				}
				else {
					myQueue.push(currentNode->GetLeft());
				}
			}
			else {
				if (currentNode->GetRight() == NULL) {
					//set new node as Red Color
					newNode->SetColor(false);

					//set the parent of new node as currentNode 
					newNode->SetParent(currentNode);
					
					// add new node as currentNode's right child
					currentNode->SetRight(newNode);
					
					// set the child is the right child
					newNodeleftChild = false;
					break;
				}
				else {
					myQueue.push(currentNode->GetRight());
				}
			}
		}
	}

	// Repeat this step for recoloring and checking
	while(checkRedBlackTree) {
	
		// Get newNode' parent 
		Node *parent = newNode->GetParent();
		
		// Get newNode's gradParent
		Node *grandParent = newNode->GetParent()->GetParent();
		
		// Setting the newNode 
		if ( newNode ==  parent->GetLeft()) {
			newNodeleftChild = true;
		}
		else {
			newNodeleftChild = false;
		}

		// Step 3: if parent of new Node is black, then exit
		if (parent->GetColor() == 2 ) {
			checkRedBlackTree = false;
			continue;	
		}
		
		// Step 4 : if parent of new node is red
		else {

			// find the sibling node of newNode's parent
			Node *sibling = NULL;
			if (grandParent->GetLeft() == parent) {
				sibling = grandParent->GetRight();
				parentleftChild = true;
			}
			else {
				sibling = grandParent->GetLeft();
				parentleftChild = false; 
			}
			// (a) If parent'sSibling node is color black or NULL, // Then perform the rotation 
			if (sibling == NULL || sibling->GetColor() == 2 ) {
				
				Node *x = NULL;
				Node *y = NULL;
				Node *temp = NULL;

				// Left Left Case
				if ( parentleftChild == true  && newNodeleftChild == true) {
					// Case of Left Left Node
					x = grandParent->GetLeft();
					y = x->GetRight();
					
					// Setting the parent of x whihc is grandparent's parent
					x->SetParent(grandParent->GetParent());
					if (grandParent != NULL && grandParent->GetParent() != NULL && grandParent->GetParent()->GetRight() == grandParent )
						grandParent->GetParent()->SetRight(x);
					else if (grandParent != NULL && grandParent->GetParent() != NULL )  
						grandParent->GetParent()->SetLeft(x);
					
					x->SetRight(grandParent);
					grandParent->SetLeft(y);
					grandParent->SetParent(x);
					
					if ( y != NULL)
						y->SetParent(grandParent);
					
					// Changing the color of the grandparent and parent
					x->SetColor(true);
					grandParent->SetColor(false);

					
				}
				// Left Right Case
				else if ( parentleftChild == true  && newNodeleftChild == false) {
				
					// Right Rotation
					x = newNode->GetLeft();
					parent->SetRight(x);
					
					newNode->SetLeft(parent);
					
					newNode->SetParent(grandParent);
					
					grandParent->SetLeft(newNode);

					parent->SetParent(newNode);
					
					// Restoring newNode, parent, in the same order
					temp =  parent;
					parent = newNode;
					newNode = temp;

					
					// Case of Left Left Node
					x = grandParent->GetLeft();
					y = x->GetRight();
					
					// Setting the parent of x whihc is grandparent's parent
					x->SetParent(grandParent->GetParent());
					if (grandParent != NULL && grandParent->GetParent() != NULL && grandParent->GetParent()->GetRight() == grandParent )
						grandParent->GetParent()->SetRight(x);
					else if (grandParent != NULL && grandParent->GetParent() != NULL )  
						grandParent->GetParent()->SetLeft(x);
					
					x->SetRight(grandParent);
					grandParent->SetLeft(y);
					grandParent->SetParent(x);
					
					if ( y != NULL)
						y->SetParent(grandParent);
					
					// Changing the color of the grandparent and parent
					x->SetColor(true);
					grandParent->SetColor(false);
					
				}
				// Right Left Case
				else if ( parentleftChild == false  && newNodeleftChild == true) {
					
					// Left Rotation
					x = newNode->GetRight();
					parent->SetLeft(x);
					
					newNode->SetRight(parent);
					parent->SetParent(newNode);
					
					newNode->SetParent(grandParent);
					grandParent->SetRight(newNode);

					
					// Restoring newNode, parent, in the same order
					temp =  parent;
					parent = newNode;
					newNode = temp;
					
					// Performing the Right Right Rotation for it
					x = grandParent->GetRight();
					y = x->GetLeft();
					
					// Setting the parent of x whihc is grandparent's parent
					x->SetParent(grandParent->GetParent());
					if (grandParent != NULL && grandParent->GetParent() != NULL && grandParent->GetParent()->GetRight() == grandParent )
						grandParent->GetParent()->SetRight(x);
					else if (grandParent != NULL && grandParent->GetParent() != NULL )  
						grandParent->GetParent()->SetLeft(x);
					
					//Need to add

					x->SetLeft(grandParent);
					grandParent->SetRight(y);
					grandParent->SetParent(x);
					
					if ( y != NULL)
						y->SetParent(grandParent);
					
					// changing the color of grandParent and x
					x->SetColor(true);
					grandParent->SetColor(false);
					
				
				}
				// Right Right Case
				else if ( parentleftChild == false  && newNodeleftChild == false) {
					
					x = grandParent->GetRight();
					y = x->GetLeft();
					
					// Setting the parent of x whihc is grandparent's parent
					x->SetParent(grandParent->GetParent());
					if (grandParent != NULL && grandParent->GetParent() != NULL && grandParent->GetParent()->GetRight() == grandParent )
						grandParent->GetParent()->SetRight(x);
					else if (grandParent != NULL && grandParent->GetParent() != NULL )  
						grandParent->GetParent()->SetLeft(x);
					
					//Need to add
					x->SetLeft(grandParent);
					grandParent->SetRight(y);
					grandParent->SetParent(x);
					
					if ( y != NULL)
						y->SetParent(grandParent);
					
					// changing the color of grandParent and x
					x->SetColor(true);
					grandParent->SetColor(false);
				}
				newNode = x;
			}
			
			parent = newNode->GetParent();
			if (parent == NULL) {
				root = newNode;
				return;
			}
			grandParent = newNode->GetParent()->GetParent();
			sibling = NULL;
			if (grandParent != NULL && grandParent->GetLeft() == parent) {
				sibling = grandParent->GetRight();
			}
			else if (grandParent != NULL ) {
				sibling = grandParent->GetLeft();
			}
				
			// If parent of new Node is root or is black then exit 
			if ( parent != NULL && parent->GetColor() == 2 ) {
				return;
			}
			// (b) If parent's Sibling node is red, then recolor and then check's parennt's parents color 
			// Recolor the new node from red to Black
			else if ( parent != NULL  && parent->GetColor() == 1 ) {
				if ( sibling == NULL || sibling->GetColor() == 2) {
					checkRedBlackTree = false;
				}
				else if (sibling->GetColor() == 1) {
					sibling->SetColor(true);
					parent->SetColor(true);
					
					// Check if grand parent is not root
					if (grandParent != root ) {
						grandParent->SetColor(false);
						newNode = grandParent;
					}
				}
			}
		}
	}
}

Node* RBT::GetNodeRecursive(Node *currentNode, int value ) {
	if (currentNode == NULL) {
		return NULL;
	}
	else if (currentNode->GetValue() == value ) {
		return currentNode;
	}
	else if (currentNode->GetValue() < value ) {
		return GetNodeRecursive(currentNode->GetRight(), value);
	}
	else {
		return GetNodeRecursive(currentNode->GetLeft(), value);
	}
}

Node* RBT::GetNode(int value) {
	Node *currentNode = root;
	return GetNodeRecursive(currentNode,value);
}

Node * RBT::GetMaxNode() {
	queue<Node*> myQueue;
	myQueue.push(root);
	Node *temp = NULL;	
	while (!myQueue.empty()) {
		Node* currentNode = myQueue.front();
		myQueue.pop();
		if (currentNode->GetRight() == NULL) {
			temp = currentNode;
			break;
		}
		else {
			myQueue.push(currentNode->GetRight());
		}
	}
	return temp;
}

void RBT::PrintTreeWalk(int orderNumber) {
	if (orderNumber == 1 ) {
		inorderTreeWalk(root);
	}
	else if (orderNumber == 2 ) {
		preorderTreeWalk(root);
	}
	else if (orderNumber == 3 ){
		postorderTreeWalk(root);
	}
}


void RBT::inorderTreeWalk(Node *currentNode){
	if (currentNode == NULL) {
		return;
	}
	inorderTreeWalk(currentNode->GetLeft());
	if (currentNode == GetMaxNode()) 
		cout << currentNode->GetValue() << " "; 
		//cout << currentNode->GetValue() << "[" << currentNode->GetColor() << "] " << currentNode->GetParent() <<  " " << currentNode->GetLeft() << " " << currentNode->GetRight() << endl; 
	else
		cout << currentNode->GetValue() << " "; 
		//cout << currentNode->GetValue() << "[" << currentNode->GetColor() << "] " << currentNode->GetParent() <<  " " << currentNode->GetLeft() << " " << currentNode->GetRight() << endl; 
	inorderTreeWalk(currentNode->GetRight());
}

void RBT::preorderTreeWalk(Node *currentNode){
	if (currentNode == NULL) {
		return;
	}
	if (currentNode == GetMaxNode()) 
		cout << currentNode->GetValue() << " "; 
	else
		cout << currentNode->GetValue() << " ";
	preorderTreeWalk(currentNode->GetLeft());
	preorderTreeWalk(currentNode->GetRight());
}

void RBT::postorderTreeWalk(Node *currentNode){
	if (currentNode == NULL) {
		return;
	}
	postorderTreeWalk(currentNode->GetLeft());
	postorderTreeWalk(currentNode->GetRight());
	if (currentNode == root) 
		cout << currentNode->GetValue() << " "; 
	else
		cout << currentNode->GetValue() << " ";
}
