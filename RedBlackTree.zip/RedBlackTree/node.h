#ifndef __NODE_H__
#define __NODE_H__

#include <cstdlib>

// Defines a node of a tree.
class Node {
private:
	int value;
	int  color; // 1 for Red and 2 for Black
	Node *parent;
	Node *leftChild;
	Node *rightChild;

public:
	// Class Constructors
	Node(int value);

	// parameterized Constructors
	Node(int value, bool color, Node *parent, Node *leftChild, Node *rightChild);

	// Class Destructors
	~Node();

	// update the node value with new Value
	void SetValue(int newValue);

	// Returns the color of the node.
	int GetColor();
	
	// Returns the value of the node.
	int GetValue();

	// Sets the color of the node.
	void SetColor(bool isBlack);
	
	// Set the parent of the node.
	void SetParent(Node *temp);

	// Set the left of the node.
	void SetLeft(Node *temp);
	
	// Set the right of the node.
	void SetRight(Node *temp);
	
	// Returns the parent of the node.
	Node* GetParent();

	// Returns the left of the node.
	Node* GetLeft();

	// Returns the right of the node.
	Node* GetRight();
};

#endif //__NODE_H__
