#ifndef __NODE_H__
#define __NODE_H__

#include <cstdlib>

// Defines a node of a tree.
class Node {
private:
	int value;
	int height;
	Node *parent;
	Node *leftChild;
	Node *rightChild;

public:
	// Class Constructors
	Node(int value);

	// parameterized Constructors
	Node(int value, Node *parent, Node *leftChild, Node *rightChild);

	// Class Destructors
	~Node();
	
	// Returns the height of the node
	int GetHeight();

	// sets the height of the node
	void SetHeight(int h);
	
	// Returns the value of the node.
	int GetValue();

	// Set the parent of the node.
	void SetParent(Node *temp);

	// Set the left of the node.
	void SetLeft(Node *temp);
	
	// Set the right of the node.
	void SetRight(Node *temp);
	
	// Returns the parent of the node.
	Node* GetParent();

	// Returns the left of the node.
	Node* GetLeft();

	// Returns the right of the node.
	Node* GetRight();
};

#endif //__NODE_H__
