#ifndef __AVL_H__
#define __AVL_H__

#include "node.h"

// Defines a binary tree.
class AVL {
private:
	Node *root;
public:
	// Constructor for AVL 
	AVL();

	// Destructor for AVL
	~AVL();
	
	// Inorder traversal for 
	void inorderTreeWalk(Node *currentNode);
	
	// Preorder traversal for AVL
	void preorderTreeWalk(Node *currentNode);
	
	// Postorder traversal for AVL
	void postorderTreeWalk(Node *currentNode);

	// Prints the list of values from the tree, using the specified order.
	void PrintTreeWalk(int orderNumber);
	
	//GetNodeRecursive return checks for value in tree in recursion
	Node* GetNodeRecursive(Node *currentNode, int value);

	// Returns the node with the specified value.
	Node* GetMaxNode(); 
	
	// compute the height balancing
	int BalanceTree(Node *);

	// rotate Left 
	Node * rotateLeft(Node *);
	
	// rotate Right 
	Node * rotateRight(Node *);
	
	// Left Left Rotation
	Node * LeftLeft(Node *);
	// Left Right Rotation
	Node * LeftRight(Node *);
	// Right Right  Rotation
	Node * RightRight(Node *);
	// Right Left  Rotation
	Node * RightLeft(Node *);

	// computes the height of current node
	int computeHeight(Node *currentNode);

	// Returns the root of the tree.
	Node* GetRoot();

	// Adds the value to the tree.
	void AddNode(int value);

	// Returns the node with the specified value.
	Node* GetNode(int value);

};

#endif
