#include "avl.h"
#include <iostream>
#include <queue>

using namespace std;

AVL::AVL() {
	root = NULL;
}

AVL::~AVL() {
	
}

Node* AVL::GetRoot( ) {
	return root;
}

void AVL::AddNode(int value) {
	
	// Creating a new node (Empty Node)
	Node  *newNode = new Node(value);

	// Set which side of the Parent newNode is added
	bool newNodeleftChild = false;
	
	// Set which side of the Parent newNode is added
	bool parentleftChild = false;
	
	// Step 1 : if root node is null, add node as root
	if ( root == NULL) {
		root = newNode;
		return;
	}
	// Step 2: Add node to  AVL 
	else {
	
		queue<Node*> myQueue;
		myQueue.push(root);
		
		Node * currentNode = NULL;
		while (!myQueue.empty()) {
			Node* currentNode = myQueue.front();
			myQueue.pop();
		
			if (currentNode->GetValue() > value ) {
				if (currentNode->GetLeft() == NULL) {
					
					//set the parent of new node as currentNode 
					newNode->SetParent(currentNode);
					
					// add new node as currentNode's left child
					currentNode->SetLeft(newNode);

					newNodeleftChild = true;
					break;
				}
				else {
					myQueue.push(currentNode->GetLeft());
				}
			}
			else {
				if (currentNode->GetRight() == NULL) {

					//set the parent of new node as currentNode 
					newNode->SetParent(currentNode);
					
					// add new node as currentNode's right child
					currentNode->SetRight(newNode);
					
					// set the child is the right child
					newNodeleftChild = false;
					break;
				}
				else {
					myQueue.push(currentNode->GetRight());
				}
			}
		}
		if (newNodeleftChild == true  && currentNode != NULL) {
			if (BalanceTree(currentNode) == 2 ) {
				if (newNode->GetValue() < currentNode->GetLeft()->GetValue()) 
					currentNode = LeftLeft(currentNode);
				else
					currentNode = LeftRight(currentNode);
			}
		}
		else if (newNodeleftChild == false && currentNode != NULL) {
			if (BalanceTree(currentNode) == -12 ) {
				if (newNode->GetValue() > currentNode->GetLeft()->GetValue()) 
					currentNode = RightRight(currentNode);
				else
					currentNode = RightLeft(currentNode);
			}

		}
	}

}

int AVL::BalanceTree(Node *currentNode){
	int leftHeight;
	int rightHeight;
	if( currentNode == NULL )
		return 0;
	
	if (currentNode->GetLeft()  == NULL )
		leftHeight = 0;
	else 
		leftHeight = 1 + currentNode->GetLeft()->GetHeight();

	if (currentNode->GetRight()  == NULL )
		rightHeight = 0;
	else 
		rightHeight = 1 + currentNode->GetRight()->GetHeight();

	return(leftHeight - rightHeight);
}

int AVL::computeHeight(Node *currentNode) {
	int leftHeight;
	int rightHeight;
	if( currentNode == NULL )
		return 0;
	
	if (currentNode->GetLeft()  == NULL )
		leftHeight = 0;
	else 
		leftHeight = 1 + currentNode->GetLeft()->GetHeight();

	if (currentNode->GetRight()  == NULL )
		rightHeight = 0;
	else 
		rightHeight = 1 + currentNode->GetRight()->GetHeight();

	if (leftHeight > rightHeight)
		return leftHeight;
	else
		return rightHeight;
}

Node * AVL::rotateLeft(Node *x){
	Node *y;
	y = x->GetRight();
	x->SetRight(y->GetLeft());
	y->SetLeft(x);
	x->SetHeight(computeHeight(x));
	y->SetHeight(computeHeight(y));
	return y;
}
Node * AVL::rotateRight(Node *x){
	Node *y;
	y = x->GetLeft();
	x->SetLeft(y->GetRight());
	y->SetRight(x);
	x->SetHeight(computeHeight(x));
	y->SetHeight(computeHeight(y));
	return y;

}
Node * AVL::LeftLeft(Node *currentNode){
	currentNode = rotateRight(currentNode);
	return currentNode;
}

Node * AVL::LeftRight(Node *currentNode) {
	currentNode->SetLeft(rotateLeft(currentNode->GetLeft()));
	currentNode = rotateRight(currentNode);
	return currentNode;
}

Node * AVL::RightRight(Node *currentNode) {
	currentNode = rotateLeft(currentNode);
	return currentNode;
}

Node * AVL::RightLeft(Node *currentNode){
	currentNode->SetRight(rotateRight(currentNode->GetRight()));
	currentNode = rotateLeft(currentNode);
	return currentNode;
}
Node* AVL::GetNodeRecursive(Node *currentNode, int value ) {
	if (currentNode == NULL) {
		return NULL;
	}
	else if (currentNode->GetValue() == value ) {
		return currentNode;
	}
	else if (currentNode->GetValue() < value ) {
		return GetNodeRecursive(currentNode->GetRight(), value);
	}
	else {
		return GetNodeRecursive(currentNode->GetLeft(), value);
	}
}

Node* AVL::GetNode(int value) {
	Node *currentNode = root;
	return GetNodeRecursive(currentNode,value);
}

Node * AVL::GetMaxNode() {
	queue<Node*> myQueue;
	myQueue.push(root);
	Node *temp = NULL;	
	while (!myQueue.empty()) {
		Node* currentNode = myQueue.front();
		myQueue.pop();
		if (currentNode->GetRight() == NULL) {
			temp = currentNode;
			break;
		}
		else {
			myQueue.push(currentNode->GetRight());
		}
	}
	return temp;
}

void AVL::PrintTreeWalk(int orderNumber) {
	if (orderNumber == 1 ) {
		inorderTreeWalk(root);
	}
	else if (orderNumber == 2 ) {
		preorderTreeWalk(root);
	}
	else if (orderNumber == 3 ){
		postorderTreeWalk(root);
	}
}


void AVL::inorderTreeWalk(Node *currentNode){
	if (currentNode == NULL) {
		return;
	}
	inorderTreeWalk(currentNode->GetLeft());
	if (currentNode == GetMaxNode()) 
		cout << currentNode->GetValue(); 
		//cout << currentNode->GetValue() << "[" << currentNode->GetColor() << "] " << currentNode->GetParent() <<  " " << currentNode->GetLeft() << " " << currentNode->GetRight() << endl; 
	else
		cout << currentNode->GetValue() << " "; 
		//cout << currentNode->GetValue() << "[" << currentNode->GetColor() << "] " << currentNode->GetParent() <<  " " << currentNode->GetLeft() << " " << currentNode->GetRight() << endl; 
	inorderTreeWalk(currentNode->GetRight());
}

void AVL::preorderTreeWalk(Node *currentNode){
	if (currentNode == NULL) {
		return;
	}
	if (currentNode == GetMaxNode()) 
		cout << currentNode->GetValue(); 
	else
		cout << currentNode->GetValue() << " ";
	preorderTreeWalk(currentNode->GetLeft());
	preorderTreeWalk(currentNode->GetRight());
}

void AVL::postorderTreeWalk(Node *currentNode){
	if (currentNode == NULL) {
		return;
	}
	postorderTreeWalk(currentNode->GetLeft());
	postorderTreeWalk(currentNode->GetRight());
	if (currentNode == root) 
		cout << currentNode->GetValue(); 
	else
		cout << currentNode->GetValue() << " ";
}
